package com.ims.api.ImsApiCart.controller;

import org.springframework.data.jpa.repository.JpaRepository;

import com.ims.api.ImsApiCart.model.Cart;

public interface CartRepository extends JpaRepository<Cart, Integer> {

}
