package com.ims.api.ImsApiCart.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import lombok.Data;

@Data
@Entity
public class CartRequestProduct
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cartreqId;
	private int productId;
	private String productName;
	private int productPrice;
	private int productQuantity;
	
  
}
