package com.ims.api.ImsApiCart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsApiCartApplicationTests {

	@Test
	void contextLoads() {
	}

}
