package com.ims.zuulApi.ZuulApi.Websecurity;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;



@Service
public class MyUserDetailsService implements UserDetailsService{
	 @Autowired
	    UserRepository userRepository;
	 @Transactional
	    public void adduser(User user)
	    {
	    	userRepository.save(user);
	    }
	   

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		 User user=userRepository.findByUsername(userName);
	       System.out.println("role"+user.getRoles());
	        return new MyUserDetails(user);
	}

}
