package com.ims.zuulApi.ZuulApi.Websecurity;

import javax.persistence.Entity;
import javax.persistence.Id;



import lombok.Data;
@Data
@Entity
public class User {
	@Id
	private String username;
	 private String email;
    private String password;
    private String roles;

}
