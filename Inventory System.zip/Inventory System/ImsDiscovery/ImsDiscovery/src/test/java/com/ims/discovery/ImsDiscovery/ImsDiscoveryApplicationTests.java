package com.ims.discovery.ImsDiscovery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsDiscoveryApplicationTests {

	@Test
	void contextLoads() {
	}

}
