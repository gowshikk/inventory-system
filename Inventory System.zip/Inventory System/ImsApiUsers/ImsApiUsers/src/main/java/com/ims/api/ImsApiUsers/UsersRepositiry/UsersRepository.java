package com.ims.api.ImsApiUsers.UsersRepositiry;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ims.api.ImsApiUsers.models.User;


@Repository
public interface UsersRepository extends JpaRepository<User, String> {

	 User findByUsername(String userName);  
	 @Query(value="select roles from user where user_name=?1",nativeQuery=true)
	 String getAuthority(String userName);

}
