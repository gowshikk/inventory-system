package com.ims.api.ImsApiUsers;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@EnableDiscoveryClient
@EnableEurekaClient
@Slf4j
public class ImsApiUsersApplication {

	public static void main(String[] args) {
		log.info("Starting Application of USers Microservices");
		SpringApplication.run(ImsApiUsersApplication.class, args);
	}

}
 