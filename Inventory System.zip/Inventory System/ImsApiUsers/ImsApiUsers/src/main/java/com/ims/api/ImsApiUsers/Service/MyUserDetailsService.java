package com.ims.api.ImsApiUsers.Service;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.ims.api.ImsApiUsers.UsersRepositiry.UsersRepository;
import com.ims.api.ImsApiUsers.models.MyUserDetails;
import com.ims.api.ImsApiUsers.models.User;



@Service

public class MyUserDetailsService implements UserDetailsService{
	 @Autowired
	    UsersRepository userRepository;
	 @Transactional
	    public void adduser(User user)
	    {
	    	userRepository.save(user);
	    }
	   

	@Override
	public UserDetails loadUserByUsername(String userName) throws UsernameNotFoundException {
		 User user=userRepository.findByUsername(userName);
	       System.out.println("role"+user.getRoles());
	        return new MyUserDetails(user);
	}

}