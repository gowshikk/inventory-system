package com.ims.api.ImsApiUsers.models.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ims.api.ImsApiUsers.JWTUtil.JwtUtil;
import com.ims.api.ImsApiUsers.Service.MyUserDetailsService;
import com.ims.api.ImsApiUsers.models.AuthenticationResponse;
import com.ims.api.ImsApiUsers.models.User;

import lombok.extern.slf4j.Slf4j;


@RestController
@RequestMapping("/users")
@Slf4j
public class UserController {

	
	@Autowired
	MyUserDetailsService myUserDetailsService;
	@Autowired
	AuthenticationManager authenticationManager;
	@Autowired
	JwtUtil jwtTokenUtil;
	
	public static String token_gen=null;
	
	@GetMapping("/status")
	public String status() {
		return"welcome";
	}
	@PostMapping("/register")
	public String Register(@Valid @RequestBody User user) {
		log.info("Registering Users in of USers Microservices");
		
		myUserDetailsService.adduser(user);
		return "Registered sucessfully ";
	}
	
	@PostMapping("/authenticate")
	public ResponseEntity<?> createAuthenticationToken(@Valid @RequestBody User user) throws Exception {
		log.info("Authenticating the USers Microservices");

		authenticate(user.getUsername(), user.getPassword());

		final UserDetails userDetails = myUserDetailsService.loadUserByUsername(user.getUsername());

		final String token = jwtTokenUtil.generateToken(userDetails);
		token_gen=token;
		log.info("Token Generated for Users "+token);
		return ResponseEntity.ok(new AuthenticationResponse(token));
	}

	private void authenticate(String username, String password) throws Exception {
		try {
			authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, password));
		} 
		catch (BadCredentialsException e) {
			log.error("Inavalid username/password.Please check your credentials");
			throw new Exception("INVALID_CREDENTIALS", e);
		}
	}
	
}
