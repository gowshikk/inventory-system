package com.ims.api.ImsApiUsers.models;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import lombok.Data;

@Data
@Entity
public class User {
    
	@Id
	@NotNull(message = "Username can't be empty")
	private String username;
	@NotNull(message = "Email can't be empty")
    private String email;
	@NotNull(message = "Password can't be null")
    private String password;
	@NotEmpty(message = "Roles can't be empty")
    private String roles;


}
