package com.ims.api.ImsApiUsers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ImsApiUsersApplicationTests {

	@Test
	void contextLoads() {
	}

}
