package com.ims.api.ImsApiProducts;

import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mockito;
import org.skyscreamer.jsonassert.JSONAssert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.test.context.junit.jupiter.SpringExtension;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.ims.api.ImsApiProducts.Service.ProductService;
import com.ims.api.ImsApiProducts.controller.ProductController;
import com.ims.api.ImsApiProducts.model.Product;
import com.ims.api.ImsApiProducts.model.StockAvailable;

@WebMvcTest(controllers = ProductController.class)
@ExtendWith(SpringExtension.class)
class ImsApiProductsApplicationTests {

	 	@Autowired
	    private MockMvc mockMvc;

	    @MockBean
	    private ProductService prodService;

	    @Autowired
	    private ObjectMapper objectMapper;

	    private List<Product> productList;
	    
	    
	    @BeforeEach
	    void setUp() {
	    	System.out.println("in before each...........");
	    	 this.productList = new ArrayList<>();
		      StockAvailable stock = new StockAvailable();
		      stock.setStockId(1);
		      stock.setStockQuantity(20);
		      Product p =new Product();
		      p.setProductId(100);
		      p.setProductName("Product1");
		      p.setProductPrice(20);
		      //stock.setProduct(p);
		      p.setProductStockQuantity(stock);
		      prodService.addproductforTest(p);
		      //prodService.addProduct(stock);
		    	System.out.println("in before each finished..........."+p);

		      
	    }
	
	@Test
	void contextLoads() throws Exception {
		
		//StockAvailable sab = new StockAvailable(1,20,new Product("Product1",20));
		//Mockito.when(prodService.findAllProductsfortest()).thenReturn(productList);
		
		RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/viewallproducts");//.accept(MediaType.APPLICATION_JSON);
		MvcResult result = mockMvc.perform(requestBuilder).andReturn();
		System.out.println("In Test Response-->"+result.getResponse().toString());
		System.out.println("In Test Expected Response-->"+productList.toString());

		//String expected = "{id:Course1,name:Spring,description:10Steps}";
		JSONAssert.assertEquals(productList.toString(), result.getResponse().getContentAsString(), true);
		
//        this.mockMvc.perform(get("/viewallproducts"))
//                .andExpect(status().isOk())
//                .andExpect(jsonPath("$.productName()", is(productList.get(0).getProduct().getProductName())));
	}

}
