package com.ims.api.ImsApiProducts.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.ims.api.ImsApiProducts.Service.ProductService;
import com.ims.api.ImsApiProducts.model.Product;
import com.ims.api.ImsApiProducts.model.StockAvailable;

import lombok.extern.slf4j.Slf4j;

@RestController
@Slf4j
public class ProductController {
	@Autowired
	private ProductService productService;
	

	private List<Product> list;
	
	@GetMapping("/status")
	public String check()
	{
		return "Working in Products Application........";
	}

	@GetMapping(value ="/viewallproducts",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<Product>> viewProducts() {
		System.out.println("Working for view all products.............");
		list = productService.findAll();
		log.info("Viewing All products {}"+list);
		System.out.println("Retrieved data for view all products.............");
		//return list.toString();
		return ResponseEntity.ok(list);
	} 
	
	@PostMapping(value ="/addproduct",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<StockAvailable> add( @RequestBody StockAvailable product) {

		productService.addProduct(product); 
		//return productService.findbyproductStockid(product.getStockId());
		return ResponseEntity.ok(productService.findbyproductStockid(product.getStockId()));
	}

	@PostMapping(value ="/updateStock",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<StockAvailable> updateStock(@Valid @RequestBody StockAvailable productStockcount) {
		log.info("Updating stock available ");
		productService.updateStock(productStockcount);
		StockAvailable sp = productService.findbyproductStockid(productStockcount.getStockId());
		log.info("After Update {}"+sp);
		
		//return sp.toString();
		return ResponseEntity.ok(sp);
	}
	
	@GetMapping(value ="/delete/{id}",produces = MediaType.APPLICATION_JSON_VALUE)//id is stock id bcoz of one to one relationship
	public ResponseEntity<?> delete(@PathVariable("id")int id)
	{
		try {
		productService.delete(id);
		}
		catch(Exception e)
		{
			return ResponseEntity.ok("Id is not Present");
		}
		return viewProducts();
	}
	
	@GetMapping(value = "/getlowstock",produces = MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<List<StockAvailable>> getLowStock()
	{
		List<StockAvailable> stock = productService.getLowStockZero();
		System.out.println(stock.toString());
		
		return ResponseEntity.ok(stock);
		
	}


}
