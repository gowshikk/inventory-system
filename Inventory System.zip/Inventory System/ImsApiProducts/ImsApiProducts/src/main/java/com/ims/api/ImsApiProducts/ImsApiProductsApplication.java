package com.ims.api.ImsApiProducts;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;

@SpringBootApplication
@EnableEurekaClient
public class ImsApiProductsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ImsApiProductsApplication.class, args);
	}

}
