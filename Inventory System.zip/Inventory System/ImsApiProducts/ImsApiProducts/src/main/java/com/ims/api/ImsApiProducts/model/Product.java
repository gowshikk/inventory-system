package com.ims.api.ImsApiProducts.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonManagedReference;
import com.ims.api.ImsApiProducts.model.StockAvailable;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Entity
public class Product {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Getter
	@Setter
	private int productId;
	@Getter
	@Setter
	@NotEmpty(message = "Mention product name")
	private String productName;
	@Getter
	@Setter
	@Min(value = 1,message = "Price must be greater than 1")
	private int productPrice;
	@Getter
	@Setter
	@OneToOne(mappedBy = "product")
	@JsonManagedReference
	private StockAvailable productStockQuantity;
	@Override
	public String toString() {
		return "Product [productId=" + productId + ", productName=" + productName + ", productPrice=" + productPrice
				+ ", productStockQuantity=" + productStockQuantity + "]";
	}

	

}
