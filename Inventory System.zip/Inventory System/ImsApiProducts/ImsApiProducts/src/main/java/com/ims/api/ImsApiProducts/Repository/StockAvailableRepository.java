package com.ims.api.ImsApiProducts.Repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.ims.api.ImsApiProducts.model.StockAvailable;

@Repository
public interface StockAvailableRepository extends JpaRepository<StockAvailable, Integer>{
	
	@Modifying
	@Query("UPDATE  StockAvailable s  set s.stockQuantity=s.stockQuantity + ?1 where s.stockId=?2")
	void updateStockQuantity(int count,int stockId);

	@Query("SELECT s from StockAvailable s WHERE s.stockQuantity="+0)
	List<StockAvailable> findLowStock();
		
    
}