package com.ims.api.ImsApiProducts.model;
import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.validation.constraints.NotEmpty;

import com.fasterxml.jackson.annotation.JsonBackReference;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;


@Entity
public class StockAvailable {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	@Getter
	@Setter
	private int stockId;
	@Getter
	@Setter
	private int stockQuantity;
	@OneToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="product_id")
	@JsonBackReference
	private Product product;
	@Override
	public String toString() {
		return "StockAvailable [stockId=" + stockId + ", stockQuantity=" + stockQuantity + "]";
	}
	
	
	
	
	
} 
 