package com.ims.api.ImsApiProducts.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.ims.api.ImsApiProducts.Repository.ProductRepository;
import com.ims.api.ImsApiProducts.Repository.StockAvailableRepository;
import com.ims.api.ImsApiProducts.model.Product;
import com.ims.api.ImsApiProducts.model.StockAvailable;

import lombok.extern.slf4j.Slf4j;
@Slf4j
@Service
public class ProductService {

	@Autowired
	private StockAvailableRepository stockRepository;
	@Autowired
	private ProductRepository productRepository;
     
	@Transactional
	public void updateStock(StockAvailable updatecount) {
		log.info("Update the Stocks Available");
		stockRepository.updateStockQuantity(updatecount.getStockQuantity(),updatecount.getStockId());
	}
	
	public void addProduct(StockAvailable product) {
		log.info("Adding a new product to the database");
		stockRepository.save(product);
		
	}

	public StockAvailable findbyproductStockid(int stockId) {
		return stockRepository.findById(stockId).get();
	}

	public List<Product> findAll() {
		log.info("Retrieving all products from database");
		return productRepository.findAll();
	}

	public List<StockAvailable> findAllProducts() {
		log.info("Retrieving all products from database");
		return stockRepository.findAll();
	}

	public void delete(int id) {

		stockRepository.deleteById(id);
	}

	public void addproductforTest(Product p) {

		productRepository.save(p);
	}

	public List<Product> findAllProductsfortest() {
		log.info("Retrieving all products from database");
		return productRepository.findAll();
	}

	public List<StockAvailable> getLowStockZero() {
		return stockRepository.findLowStock();
	}
}
